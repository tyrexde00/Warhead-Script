-- Armed Containment Area 13 V3 Functional Warhead Script --
-- Made by Marc & Tyrex --
-- Discord: tyrex_de --
-- Steam: https://steamcommunity.com/id/tyrex_de/ --

-- I made the Warheads functional on the map using a script that was originaly made by Marc but strongly edited by myself. Currently, it only works with GuthSCP keycards and some random Jobs. --

if CLIENT then return end

local CHECK_MODE = "both"

local ALLOWED_JOBS = {
    [TEAM_SITEDIRECTOR]   = true,
    [TEAM_O5COUNCIL]      = true,
    [TEAM_HEADOFSECURITY] = true,
}

local ALLOWED_KEYCARDS = {
    ["guthscp_keycard_lvl_5"] = true,
    ["guthscp_keycard_omni"]  = true,
}

local DENY_MESSAGE_KEYCARD = "You need at least a Level-5 Keycard in your hand."
local DENY_MESSAGE_JOB     = "Your job has no access to this facility."
local DENY_MESSAGE_BOTH    = "You need the correct job and at least a Level-5 Keycard."
local SOUND_DENY    = "buttons/button10.wav"
local SOUND_SUCCESS = "ambient/alarms/klaxon1.wav"

NukeButtonTable = {
    ["invisible_lua_alpha"] = { button = "alpha_warhead_sequence_button", name = "Alpha" },
    ["invisible_lua_omega"] = { button = "omega_warhead_sequence_button", name = "Omega" },
}

local function HasValidKeycard(ply)
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) then return false end
    return ALLOWED_KEYCARDS[wep:GetClass()] == true
end

local function HasValidJob(ply)
    return ALLOWED_JOBS[ply:Team()] == true
end

local function NotifyDeny(ply, msg)
    ply:ChatPrint("[Sicherheitssystem] " .. msg)
    ply:EmitSound(SOUND_DENY)
end

local function NotifySuccess(ply, sequenceName)
    ply:ChatPrint("[Sicherheitssystem] You have successfully started the " .. sequenceName .. "-Sequence!")
    ply:EmitSound(SOUND_SUCCESS)
end

hook.Add("PlayerUse", "UseNukeButtons", function(ply, ent)
    if not IsValid(ent) or not IsValid(ply) then return end
    local entName = ent:GetName()
    if not entName then return end
    local nukeData = NukeButtonTable[entName]
    if not nukeData then return end
    local hasKeycard = HasValidKeycard(ply)
    local hasJob     = HasValidJob(ply)
    if CHECK_MODE == "keycard" then
        if not hasKeycard then
            NotifyDeny(ply, DENY_MESSAGE_KEYCARD)
            return false
        end
    elseif CHECK_MODE == "job" then
        if not hasJob then
            NotifyDeny(ply, DENY_MESSAGE_JOB)
            return false
        end
    elseif CHECK_MODE == "both" then
        if not hasKeycard and not hasJob then
            NotifyDeny(ply, DENY_MESSAGE_BOTH)
            return false
        elseif not hasKeycard then
            NotifyDeny(ply, DENY_MESSAGE_KEYCARD)
            return false
        elseif not hasJob then
            NotifyDeny(ply, DENY_MESSAGE_JOB)
            return false
        end
    end
    local buttonEnt = ents.FindByName(nukeData.button)[1]
    if not IsValid(buttonEnt) then return end
    buttonEnt:Use(Entity(0))
    NotifySuccess(ply, nukeData.name)
end)